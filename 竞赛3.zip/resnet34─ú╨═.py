import torch
import os
import torch.nn as nn
from PIL import Image
from torch.nn import functional as F
from torchvision import transforms as T
from torch.utils.data import Dataset,DataLoader
from sklearn.externals import joblib

class init_img(Dataset):
    def __init__(self,root):
        images = os.listdir(root)
        self.images = [os.path.join(root, image) for image in images if image.endswith('.jpg')]
        
    def __getitem__(self,index):
        all_label = ['0','1','2','3','4','5','6','7','8','9','a','b','c','d','e','f',\
                     'g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w',\
                     'x','y','z','A','B','C','D','E','F','G','H','I','J','K','L','M','N',\
                     'O','P','Q','R','S','T','U','V','W','X','Y','Z']
        image_path = self.images[index]
        pil_image = Image.open(image_path)
        index = image_path.split('/')[-1].split('.')[0].split('_')[-1]
        label = image_path.split('/')[-1].split('.')[0].split('_')[-2]
        label_list = torch.zeros(62).type(torch.FloatTensor)
        label_list[all_label.index(label[int(index)])] = 1.0
        data = T.ToTensor()(pil_image)
        return data, label_list
    
    def __len__(self):
        return len(self.images)
    

class ResidualBlock(nn.Module):
    '''
    实现子Module:ResidualBlock
    '''
    def __init__(self, inchannel, outchannel, stride=1, shortcut=None):
        super(ResidualBlock,self).__init__()
        self.left=nn.Sequential(
                nn.Conv2d(inchannel, outchannel, 3, stride, 1 , bias=False),
                nn.BatchNorm2d(outchannel),
                nn.ReLU(inplace=True),
                nn.Conv2d(outchannel, outchannel, 3,1,1,bias=False),
                nn.BatchNorm2d(outchannel))
        self.right=shortcut
        
    def forward(self,x):
        out=self.left(x)
        residual=x if self.right is None else self.right(x)
        out+=residual
        return F.relu(out)
    
class ResNet(nn.Module):
    '''
    实现主Module:ResNet34
    ResNet34包含多个layer，每个layer又包含多个reesidal block
    用子module实现residual block，用_make_layer函数实现layer
    '''
    def __init__(self, num_classes=62):
        super(ResNet,self).__init__()
        self.pre=nn.Sequential(
                nn.Conv2d(1,64,7,2,3,bias=False),
                nn.BatchNorm2d(64),
                nn.ReLU(inplace=True),
                nn.MaxPool2d(3,2,1)
                )
        self.layer1=self._make_layer(64, 128 ,  3)
        self.layer2=self._make_layer(128, 256 , 4, stride=2)
        self.layer3=self._make_layer(256, 512 , 6, stride=2)
#        self.layer4=self._make_layer(512, 1024 , 3, stride=2)
        
        self.fc=nn.Linear(512,num_classes)
        
    def _make_layer(self, inchannel, outchannel, block_num, stride=1):
        '''
        构建layer，包含多个residual
        '''
        shortcut=nn.Sequential(
                nn.Conv2d(inchannel, outchannel, 1, stride, bias=False),
                nn.BatchNorm2d(outchannel))
        
        layers=[]
        layers.append(ResidualBlock(inchannel, outchannel, stride, shortcut))
        
        for i in range(1, block_num):
            layers.append(ResidualBlock(outchannel, outchannel))
        
        return nn.Sequential(*layers)
    
    def forward(self,x):
        x=self.pre(x)
        x=self.layer1(x) 
        x=self.layer2(x)
        x=self.layer3(x)
#        x=self.layer4(x)
        x=F.avg_pool2d(x,2)
        x=x.view(x.size(0),-1)
        x=self.fc(x)
        return x

    
    

dataset = init_img('init_train')

model = ResNet()
#model = joblib.load('save/model_update1.pkl')
batch_size = 128
max_epoch = 15
step = 0

n_critic = 1 
dataloader = DataLoader(dataset=dataset,batch_size=batch_size,shuffle=True,drop_last=True)
criterion = nn.BCELoss()
#criterion = nn.CrossEntropyLoss()
optimizer = torch.optim.Adam(model.parameters(), lr=0.0001)

for epoch in range(max_epoch):
    for idx, (images,labels) in enumerate(dataloader):
        
#        images = images
#        labels = labels
        
        #forward pass
        outputs = model(images)
        outputs=torch.sigmoid(outputs)
#        print(outputs)
        loss = criterion(outputs,labels)
        
        #Backward and optimize
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        
        step += 1
##       
        if step % 10 == 0:
            print('Epoch: {}/{}, Step: {}, model Loss: {}'.format(epoch, max_epoch, step, loss.item()))
        
    joblib.dump(model, 'save/model_update.pkl')
#joblib是sklearn的外部模块。
 #jbolib模块

#保存Model(注:save文件夹要预先建立，否则会报错)
joblib.dump(model, 'save/model_update.pkl')

    
