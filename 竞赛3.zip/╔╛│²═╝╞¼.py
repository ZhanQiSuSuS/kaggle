import os
import numpy as np
from PIL import Image


root = 'init_train/'
images = os.listdir(root)
images = [os.path.join(root, image) for image in images if image.endswith('.jpg')]
for i in images:
    pil_image = Image.open(i)
    image_array = np.hstack(np.asarray(pil_image)).tolist()
    if image_array.count(255) > 720:
        os.remove(i)
