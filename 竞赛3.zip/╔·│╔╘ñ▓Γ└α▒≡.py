import pandas as pd
import os
import numpy as np
from PIL import Image
from torchvision import transforms as T
from torch.utils.data import Dataset
from sklearn.externals import joblib



class init_img(Dataset):
    def __init__(self,root):
        images = os.listdir(root)
        self.images = [os.path.join(root, image) for image in images if image.endswith('.jpg')]
        
    def __getitem__(self,index):
        image_path = self.images[index]
        pil_image = Image.open(image_path)
        index = image_path.split('/')[-1].split('.')[0].split('_')[-1]
        label = image_path.split('/')[-1].split('.')[0].split('_')[-2]
        data = T.ToTensor()(pil_image)

        return data, int(label), int(index)
    
    def __len__(self):
        return len(self.images)

all_label = ['0','1','2','3','4','5','6','7','8','9','a','b','c','d','e','f',\
             'g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w',\
             'x','y','z','A','B','C','D','E','F','G','H','I','J','K','L','M','N',\
             'O','P','Q','R','S','T','U','V','W','X','Y','Z']

dataset = init_img('init_test')
model = joblib.load('save/model_all.pkl')
y_test = ['0']  * len(dataset)
y_test = np.array(y_test).reshape(-1, 5).tolist()

for index in range(len(dataset)):
    if index % 100 == 0:
        print(index)
    pre = model(dataset[index][0].view(1,1,30,30)).tolist()[0]
    pre_label = all_label[pre.index(max(pre))]
    grade = dataset[index][1]
    gi = dataset[index][2]
    y_test[grade][gi] = pre_label
    
for i in range(len(y_test)):
    y_test[i] = ''.join(y_test[i])
    

df = pd.DataFrame({'id':np.arange(20000),'y':y_test})
df.to_csv("test_llll.csv",index=False,sep=',')
