import torch
import cv2
#from sklearn import preprocessing
#from torch import nn
from torchvision import transforms as T
from torch.utils.data import Dataset
from skimage.measure import label, regionprops
from PIL import Image
#import matplotlib.pyplot as plt
import os
import numpy as np


transforms = T.Compose([  
        T.Grayscale(num_output_channels=1),
        T.Resize((30,150)),
        T.ToTensor(),
        ])
to_image = T.ToPILImage()

class init_img(Dataset):
    def __init__(self,root,transforms=None):
        images = os.listdir(root)
        self.images = [os.path.join(root, image) for image in images if image.endswith('.jpg')]
        self.transforms = transforms
        
    def __getitem__(self,index):
        image_path = self.images[index]
        pil_image = Image.open(image_path)
        label = image_path.split('/')[-1].split('.')[0]
        if self.transforms:
            data = self.transforms(pil_image)
        else:
            image_array = np.asarray(pil_image)
            data = torch.from_numpy(image_array)
        return data, label
    
    def __len__(self):
        return len(self.images)
    
def two_valued_img(dataset, index):
    r = dataset[index][0].view(30, 150)*255
    gray_h = [0]*256
    gray_h = gray_histogram(r, gray_h)
    threshold = gray_h.index(max(gray_h))
    r = binarizing(r, threshold, 10)
    r = (r/255)
    return [r, dataset[index][1]]

def gray_histogram(img, gray_h):
    h, w = img.size()
    for y in range(h):
        for x in range(w):
            px = int(img[y][x].tolist())
            gray_h[px] += 1
    return gray_h

def binarizing(img, threshold, b):
    h, w = img.size()
    for y in range(h):
        for x in range(w):
            if img[y][x] > threshold-b and img[y][x] < threshold+b:
                img[y][x] = 255
            else:
                img[y][x] = 0
    return img

#def depoint(img):   #input: gray image
#    h, w = img.size()
#    for y in range(1,h-1):
#        for x in range(1,w-1):
#            count = 0
#            if img[y-1][x] > 0.95:
#                count = count + 1
#            if img[y+1][x] > 0.95:
#                count = count + 1
#            if img[y][x-1] > 0.95:
#                count = count + 1
#            if img[y][x+1] > 0.95:
#                count = count + 1
#            if count > 2:
#                img[y][x] = 1
#    return img
#
#def gray_img(img):
#    c, h, w = img.size()
#    new_img = torch.zeros(30, 150)
#    r = img[0]
#    g = img[1]
#    b = img[2]
#    for y in range(h):
#        for x in range(w):
##            new_img[y][x] = 0.3*r[y][x] + 0.59*g[y][x] + 0.11*b[y][x]
#            new_img[y][x] = max(r[y][x], g[y][x], b[y][x])
#    return new_img.view(1,30,150)

def close_demo(image):

#    ret, binary = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)
#    cv2.imshow("binary", binary)
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (2, 2))
    binary = cv2.morphologyEx(image, cv2.MORPH_CLOSE, kernel)
    binary = torch.from_numpy(binary)
    return binary/255

def denoising(img, label_img, index):
    h, w = label_img.shape
    for x in range(h):
        for y in range(w):
            if label_img[x][y] == index:
                img[x][y] = 1
    return img

def split_img(x, y, info):
    for j in range(5):
        img_s = info[0][:,:,j*30:(j+1)*30]
        label_s = info[1] + '_' + str(j)
        x.append(img_s)
        y.append(label_s)
    return x, y


def main():
    
    x_train = list()
    y_train = list()
    dataset_train = init_img('test/',transforms)
    for i in range(len(dataset_train)):
        img_info = two_valued_img(dataset_train, i)
        print(i)
        img_t = close_demo(np.array(img_info[0]*255))
        label_data = label(img_t, connectivity=1,background = 1)
        props = regionprops(label_data)
        for i in props:
            if i.area < 10:
                img_t = denoising(img_t, label_data, i.label)
        img_info[0] = img_t.view(1, 30, 150)
        x_train, y_train = split_img(x_train, y_train, img_info)
    for i in range(len(x_train)):
        rr3 = to_image(x_train[i])
        rr3.save('init_test/'+str(i)+'_'+y_train[i]+'.jpg')
    
    


if __name__ == '__main__':
    main()