import numpy as np
import pandas as pd

def distant(test, train):
    return np.sqrt(abs((test[0]-train[0])*(test[1]-train[1])))

def knn():
    global test_data
    train_lable = train_set[:, -1]
    train_data = train_set[:, :-1]
    mean_value = np.mean(train_data, axis = 0)
    standard_deviation = np.sqrt(np.mean((train_data - mean_value)**2, axis = 0))
    train_data = (train_data - mean_value)/standard_deviation
    test_data = (test_data - mean_value)/standard_deviation
    test_distant = list()
    test_index = list()
    test_pre = list()
    for i in test_data:
        d = list()
        for j in train_data:
            d.append(distant(i, j))
        test_distant.append(d)
    for i in test_distant:
        i_sort = sorted(i)
        index = list()
        for p in range(k):
            index.append(train_lable[i.index(i_sort[p])])
        test_index.append(index)
    for i in test_index:
        test_pre.append(0) if i.count(0.0)>i.count(1.0) else test_pre.append(1)
    df = pd.DataFrame({'id':np.arange(1, len(test_pre)+1),'y':test_pre})
    df.to_csv("test.csv",index=False,sep=',')

filename1 = 'HTRU_2_train.csv'
filename2 = 'HTRU_2_test.csv'
train_set = np.loadtxt(filename1, delimiter = ",")
test_data = np.loadtxt(filename2, delimiter = ",")

k = 45
knn()