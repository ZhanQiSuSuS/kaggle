import numpy as np
import pandas as pd
from sklearn.preprocessing import Imputer
from sklearn import preprocessing
from sklearn.neural_network import MLPClassifier

def init_dataset(x_train, x_test):
    '''
    缺失值处理
    '''
    imp = Imputer(missing_values=np.nan, strategy='median')
    imp.fit(x_train)
    x_test = imp.transform(x_test)
    x_train = imp.transform(x_train)
    return x_train, x_test

def main():
    filename1 = 'train.csv'
    filename2 = 'test.csv'
    dataset_train = pd.read_csv(filename1, header=-1, na_values='?')
    dataset_test = pd.read_csv(filename2, header=-1, na_values='?')
    dataset_train = np.array(dataset_train)
    dataset_test = np.array(dataset_test)
    x_train = dataset_train[:, :-1]
    y_train = dataset_train[:, -1]
    x_test = dataset_test   
    x_train, x_test = init_dataset(x_train, x_test)
    x_train = preprocessing.normalize(x_train, norm = 'l2')
    x_test = preprocessing.normalize(x_test, norm = 'l2')
    mlp = MLPClassifier(hidden_layer_sizes=(100,50,25,))
    mlp.fit(x_train, y_train)
    print(mlp.loss_)
    test_pre = mlp.predict(x_test)
    test_pre = np.array(test_pre, dtype = int).tolist()
    df = pd.DataFrame({'id':np.arange(1, len(test_pre)+1),'y':test_pre})
    df.to_csv("testaa.csv",index=False,sep=',')
    

if __name__ == '__main__':
    main()